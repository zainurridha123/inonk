<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $agama = $_POST["agama"];
    $jabatan = $_POST["jabatan"];
    $status = $_POST["status"];
    $jumlah_anak = $_POST["jumlah_anak"];

    // Outputkan hasil
    echo "<h2>Hasil Formulir:</h2>";
    echo "<p>Nama Pegawai: $nama</p>";
    echo "<p>Agama: $agama</p>";
    echo "<p>Jabatan: $jabatan</p>";
    echo "<p>Status: $status</p>";
    echo "<p>Jumlah Anak: $jumlah_anak</p>";
}
?>
